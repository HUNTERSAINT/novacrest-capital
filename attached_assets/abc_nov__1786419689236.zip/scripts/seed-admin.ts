import { createRequire } from "module";
const require = createRequire(import.meta.url);
import * as crypto from "crypto";
import * as path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

// Dynamic import to avoid module resolution issues
const { db, usersTable, plansTable } = await import("../lib/db/src/index.js");
const { eq } = await import("drizzle-orm");

// Seed admin
const adminHash = hashPassword("Admin@123456");
const demoHash = hashPassword("Demo@123456");

const existingAdmin = await db.select().from(usersTable).where(eq(usersTable.email, "admin@novacrest.com"));
if (existingAdmin.length === 0) {
  await db.insert(usersTable).values({
    email: "admin@novacrest.com",
    passwordHash: adminHash,
    fullName: "Novacrest Admin",
    role: "admin",
    status: "active",
    balance: 0,
    totalInvested: 0,
    totalProfit: 0,
    referralCode: "ADMIN001",
  });
  console.log("✅ Admin user created: admin@novacrest.com / Admin@123456");
} else {
  console.log("⚠️  Admin user already exists");
}

const existingDemo = await db.select().from(usersTable).where(eq(usersTable.email, "demo@novacrest.com"));
if (existingDemo.length === 0) {
  await db.insert(usersTable).values({
    email: "demo@novacrest.com",
    passwordHash: demoHash,
    fullName: "Alex Sovereign",
    role: "user",
    status: "active",
    balance: 15000,
    totalInvested: 5000,
    totalProfit: 1250,
    referralCode: "DEMO001",
  });
  console.log("✅ Demo user created: demo@novacrest.com / Demo@123456");
} else {
  console.log("⚠️  Demo user already exists");
}

// Plans
const existingPlans = await db.select().from(plansTable);
if (existingPlans.length === 0) {
  await db.insert(plansTable).values([
    {
      name: "Bronze Starter",
      description: "Begin your crypto journey with our entry-level plan.",
      minAmount: 100,
      maxAmount: 999,
      roiPercent: 5.0,
      durationDays: 30,
      tier: "bronze",
      isActive: true,
      features: ["5% ROI in 30 days", "Dedicated support", "Daily profit updates", "Instant withdrawals"],
    },
    {
      name: "Silver Growth",
      description: "Scale your portfolio with consistent returns.",
      minAmount: 1000,
      maxAmount: 4999,
      roiPercent: 8.5,
      durationDays: 30,
      tier: "silver",
      isActive: true,
      features: ["8.5% ROI in 30 days", "Priority support", "Daily profit updates", "Weekly market reports"],
    },
    {
      name: "Gold Elite",
      description: "Premium returns for serious investors.",
      minAmount: 5000,
      maxAmount: 19999,
      roiPercent: 12.0,
      durationDays: 30,
      tier: "gold",
      isActive: true,
      features: ["12% ROI in 30 days", "VIP support", "Real-time profit tracking", "Portfolio analysis"],
    },
    {
      name: "Platinum Prestige",
      description: "Exclusive access to our highest-yield strategies.",
      minAmount: 20000,
      maxAmount: 99999,
      roiPercent: 18.0,
      durationDays: 30,
      tier: "platinum",
      isActive: true,
      features: ["18% ROI in 30 days", "Personal account manager", "Portfolio analysis", "Referral bonus 2x"],
    },
    {
      name: "Diamond Sovereign",
      description: "The pinnacle of crypto investment.",
      minAmount: 100000,
      maxAmount: null,
      roiPercent: 25.0,
      durationDays: 30,
      tier: "diamond",
      isActive: true,
      features: ["25% ROI in 30 days", "Dedicated wealth advisor", "Private market intelligence", "Full portfolio management"],
    },
  ]);
  console.log("✅ 5 investment plans created");
} else {
  console.log(`⚠️  ${existingPlans.length} plans already exist`);
}

console.log("\n🎉 Seed complete!");
process.exit(0);
